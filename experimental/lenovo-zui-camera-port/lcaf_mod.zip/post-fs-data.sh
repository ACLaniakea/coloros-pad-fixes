#!/system/bin/sh
MODDIR=${0%/*}
# ZUI 相机 Morpho 算法需要 /system/etc/camera/lcaf/ 配置（ColorOS 缺失 -> SIGILL）
mkdir -p /mnt/lcaf_upper /mnt/lcaf_work 2>/dev/null
mount -t tmpfs tmpfs /mnt/lcaf_upper 2>/dev/null
mount -t overlay overlay -o lowerdir=${MODDIR}/system/etc:/system/etc,upperdir=/mnt/lcaf_upper,workdir=/mnt/lcaf_work /system/etc 2>/dev/null
exit 0
